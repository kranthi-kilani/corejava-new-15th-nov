package com.capg.ems.dao;

import java.util.ArrayList;
import java.util.Iterator;

import com.capg.ems.bean.EmployeeBean;

public class EmployeeDAOImp implements IEmployeeDAO {
	
	@Override
	public boolean insertEmployee(EmployeeBean e) {
		{
			return empList.add(e);
		}
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<EmployeeBean> display() {
		// TODO Auto-generated method stub
		
		
		
		
		return empList;
	}

}
