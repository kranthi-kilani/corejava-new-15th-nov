package com.capg.ems.dao;

import java.util.ArrayList;
import java.util.Iterator;

import com.capg.ems.bean.EmployeeBean;

public interface IEmployeeDAO {
	ArrayList<EmployeeBean> empList=new ArrayList<EmployeeBean>();

   public boolean insertEmployee(EmployeeBean e);

	public ArrayList<EmployeeBean> display();

}
