package com.capg.ems.test;
import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.ems.bean.EmployeeBean;
import com.capg.ems.exception.EmployeeException;
import com.capg.ems.service.EmployeeServiceimp;
import com.capg.ems.service.IEmployeeService;

public class EmployeeServiceImpTest  {
	
	private static IEmployeeService employeeService=null;
	
	
	@BeforeClass
	public static void testDetails(){
		
		employeeService =new EmployeeServiceimp();
		
	
		
	}
	@Test(expected=EmployeeException.class)
	public  void testEidForLength() throws EmployeeException{
		
      EmployeeBean employeeBean=new EmployeeBean();
      employeeBean.setEid(90);
      employeeBean.setEname("kranthi");
      employeeBean.setSal(6000);
      employeeBean.setDept("mech");
       boolean result= employeeService.validateData(employeeBean);
      assertFalse(result);
      
		
	}
	
	@Test(expected=EmployeeException.class)
	public  void testEidForNumber() throws EmployeeException{
		
      EmployeeBean employeeBean=new EmployeeBean();
      employeeBean.setEid(22%67);
      employeeBean.setEname("kranthi");
      employeeBean.setSal(6000);
      employeeBean.setDept("mech");
       boolean result= employeeService.validateData(employeeBean);
      assertFalse(result);
      
	}
      @Test
  	public  void testEid() throws EmployeeException{
  		
        EmployeeBean employeeBean=new EmployeeBean();
        employeeBean.setEid(5789);
        employeeBean.setEname("kranthi");
        employeeBean.setSal(6000);
        employeeBean.setDept("mech");
         boolean result= employeeService.validateData(employeeBean);
        assertTrue(result);
        
  		
  	}

      @Test(expected=EmployeeException.class)
  	public  void testEnameForChar() throws EmployeeException{
  		
        EmployeeBean employeeBean=new EmployeeBean();
        employeeBean.setEid(27534);
        employeeBean.setEname("796");
        employeeBean.setSal(6000);
        employeeBean.setDept("mech");
         boolean result= employeeService.validateData(employeeBean);
        assertFalse(result);
        
  		
  	}
      @Test(expected=EmployeeException.class)
  	public  void testEnameForNotNull() throws EmployeeException{
  		
        EmployeeBean employeeBean=new EmployeeBean();
        employeeBean.setEid(345834);
        employeeBean.setEname("");
        employeeBean.setSal(6000);
        employeeBean.setDept("mechtry");
         boolean result= employeeService.validateData(employeeBean);
        assertFalse(result);
        
  		
  	}

      @Test(expected=EmployeeException.class)
  	public  void testEnameForLength() throws EmployeeException{
  		
        EmployeeBean employeeBean=new EmployeeBean();
        employeeBean.setEid(583475);
        employeeBean.setEname("kra");
        employeeBean.setSal(6000);
        employeeBean.setDept("mech");
         boolean result= employeeService.validateData(employeeBean);
        assertFalse(result);
        
  		
  	}

      @Test
  	public  void testEname() throws EmployeeException{
  		
        EmployeeBean employeeBean=new EmployeeBean();
        employeeBean.setEid(375983);
        employeeBean.setEname("kranthi");
        employeeBean.setSal(6000);
        employeeBean.setDept("mech");
         boolean result= employeeService.validateData(employeeBean);
        assertTrue(result);
        
  		
  	}
      
      
      @Test(expected=EmployeeException.class)
  	public  void testEsalGreaterZero() throws EmployeeException{
  		
        EmployeeBean employeeBean=new EmployeeBean();
        employeeBean.setEid(2454);
        employeeBean.setEname("kranthi");
        employeeBean.setSal(-1);
        employeeBean.setDept("mechry");
         boolean result= employeeService.validateData(employeeBean);
        assertFalse(result);
        
  		
  	}
      @Test
  	public  void testESal() throws EmployeeException{
  		
        EmployeeBean employeeBean=new EmployeeBean();
        employeeBean.setEid(24537);
        employeeBean.setEname("kranthi");
        employeeBean.setSal(6000);
        employeeBean.setDept("mechtu");
         boolean result= employeeService.validateData(employeeBean);
        assertTrue(result);
        
  		
  	}
      
      @Test(expected=EmployeeException.class)
  	public  void testDeptNotNUll() throws EmployeeException{
  		
        EmployeeBean employeeBean=new EmployeeBean();
        employeeBean.setEid(89789);
        employeeBean.setEname("kranthi");
        employeeBean.setSal(6000);
        employeeBean.setDept("");
         boolean result= employeeService.validateData(employeeBean);
        assertFalse(result);
        
  		
  	}
      
      @Test(expected=EmployeeException.class)
  	public  void testDeptChar() throws EmployeeException{
  		
        EmployeeBean employeeBean=new EmployeeBean();
        employeeBean.setEid(225667);
        employeeBean.setEname("kranthi");
        employeeBean.setSal(6000);
        employeeBean.setDept("565");
         boolean result= employeeService.validateData(employeeBean);
        assertFalse(result);
        
  		
  	}
      @Test
  	public  void testDept() throws EmployeeException{
  		
        EmployeeBean employeeBean=new EmployeeBean();
        employeeBean.setEid(225667);
        employeeBean.setEname("kranthi");
        employeeBean.setSal(6000);
        employeeBean.setDept("mechh");
         boolean result= employeeService.validateData(employeeBean);
        assertTrue(result);
        
  		
  	}  
      
      
      
      
      
      
      
      
      
      
      
      
      
      
}



