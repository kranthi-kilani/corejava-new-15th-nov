package com.capg.ems.service;

import java.util.ArrayList;

import com.capg.ems.bean.EmployeeBean;
import com.capg.ems.dao.EmployeeDAOImp;
import com.capg.ems.dao.IEmployeeDAO;
import com.capg.ems.exception.EmployeeException;
import com.capg.ems.exception.EmployeeNotFoundException;

public class EmployeeServiceimp implements IEmployeeService {
	IEmployeeDAO dao=new EmployeeDAOImp();

	@Override
	public boolean insertEmployee(EmployeeBean e) {
		// TODO Auto-generated method stub
		return dao.insertEmployee(e);
	}

	@Override
	public ArrayList<EmployeeBean> display() {

		
		return dao.display();
		
	
		}


public boolean validateData(EmployeeBean e) throws EmployeeException{
       boolean isValid=false;

              if((e.getEid()<999)){
                    throw new EmployeeException(EmployeeNotFoundException.ERROR1);
                   
              }
              if((e.getEname().trim().length()<5)){
                    throw new EmployeeException(EmployeeNotFoundException.ERROR2);
                    
              }
              if((e.getSal()<=0)){
            	  
                    throw new EmployeeException(EmployeeNotFoundException.ERROR3);
                  
              }
              
              if((e.getDept().trim().length()<4)){
                  throw new EmployeeException(EmployeeNotFoundException.ERROR4);
                
              }
isValid=true;


return isValid;
}

                
}

