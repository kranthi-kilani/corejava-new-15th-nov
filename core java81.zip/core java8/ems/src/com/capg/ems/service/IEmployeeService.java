package com.capg.ems.service;

import java.util.ArrayList;

import com.capg.ems.bean.EmployeeBean;
import com.capg.ems.exception.EmployeeException;
import com.capg.ems.exception.EmployeeNotFoundException;

public interface IEmployeeService {
	public boolean insertEmployee(EmployeeBean e);
	
	public ArrayList<EmployeeBean> display();
	
	public boolean validateData(EmployeeBean e) throws EmployeeException;


	

}
