package com.capg.ems.exception;

public class EmployeeNotFoundException extends Exception{

       public static final String ERROR1 = "id should be greater than 4 digits";
       public static final String ERROR2 = "name should be greater than 4 characters";
       public static final String ERROR3 = "salary should be greater than zero";
       public static final String ERROR4 = "dept field should not be integer";


}



