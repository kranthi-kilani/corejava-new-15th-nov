package com.capg.ems.ui;

import java.util.Scanner;

import com.capg.ems.bean.EmployeeBean;
import com.capg.ems.exception.EmployeeException;
import com.capg.ems.exception.EmployeeNotFoundException;
import com.capg.ems.service.EmployeeServiceimp;
import com.capg.ems.service.IEmployeeService;

public class Client {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IEmployeeService service= new EmployeeServiceimp();
		
	try{
		
	
		Scanner sc = new Scanner(System.in);
		System.out.println("enter eid");
		int eid=sc.nextInt();
		System.out.println("enter the ename");
		String ename=sc.next();
		System.out.println("enter the salary");
		double sal=sc.nextDouble();
		System.out.println("enter the dept");
		String dept=sc.next();
		EmployeeBean e=new EmployeeBean();
	
	    	e.setEid(eid);
			e.setEname(ename);
			e.setSal(sal);
			e.setDept(dept);
	
		
		boolean isValid	=service.validateData(e);

		if(isValid){
		boolean isAdded=service.insertEmployee(e);
		
		if(isAdded){
						
			System.out.println(" -------------------Employee Successfully Added-----------------");
			//System.out.println(e);
		}
	else
		{
			System.out.println("Not added");
		}
		
		}
		else{
			System.err.println("-----------------Please enter Employee Details Properly-------------");
		}
		
		}	
	
	catch(EmployeeException  EmployeeException){
	
	System.err.println(EmployeeException.getMessage());
	
		}
	}
	
	}
			
			
		
			
		




