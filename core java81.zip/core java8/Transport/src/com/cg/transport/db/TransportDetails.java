package com.cg.transport.db;

import java.util.HashMap;
import java.util.Map;

import com.cg.transport.bean.TicketBean;

public class TransportDetails {

	private static Map<String, String> transportDetails = new HashMap<>();
	private static Map<Integer, TicketBean> ticketDetails = new HashMap<>();
	static {

		transportDetails.put("flight-1", "flight");
		transportDetails.put("train-1", "train");
		transportDetails.put("taxi-1", "taxi");

	}

	private static Map<String, String> gettransportDetails() {
		return transportDetails;

	}
}
