package com.cg.transport.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import com.cg.transport.bean.TicketBean;
import com.cg.transport.db.TransportDetails;
import com.cg.transport.service.ITransportService;
import com.cg.transport.service.TransportServiceImp;

public class TransportUI {
	ITransportService service = new TransportServiceImp();

	public static void main(String[] args) {

		TransportDetails TransDB = new TransportDetails();
		TransportUI trans = new TransportUI();
		Scanner sc = new Scanner(System.in);
		TicketBean tb = new TicketBean();
		System.out.println("enter the mode of transport");
		ArrayList mode = new ArrayList();
		mode.add("1.Flight");
		mode.add("2.Train");
		mode.add("3.Taxi");

		Iterator it = mode.iterator();
		while (it.hasNext()) {
			String mode1 = (String) it.next();
			System.out.println(mode1);

		}
		String mode1 = sc.next();
		Map<String, String> transportDetails = new HashMap<String, String>();

		String when = null;
		tb.setWhen(when);
		System.out.println("When the booking is made:");
		System.out.println("1.Booking on this week");
		System.out.println("2.Booking on next week");
		System.out.println("3.Booking on next month");

		int option = sc.nextInt();
		if (option == 1) {

		}
		if (option == 2) {
			System.out.println("make a booking for the next  week");

		}
		if (option == 3) {
			System.out.println("make a booking for the next month");

		}
		System.out.println("make a booking for this week");
		// Random bookedId = new Random();
		int bookingid = (int) ((Math.random()) * 1000);
		

		System.out.println("BookingId : " + bookingid);

		LocalDateTime dateTime = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd MMMM yyyy hh:mm a");

		System.out.println(" bookingdate " + format.format(dateTime));
	}

}
