package com.cg.transport.service;

public interface ITransportService {

}
