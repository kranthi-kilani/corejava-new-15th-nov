package com.cg.transport.dao;
import java.util.HashMap;
import java.util.Map;
public interface ITransportDao {
	
	Map<String, String> transportDetails=new HashMap<String,String>();

}
