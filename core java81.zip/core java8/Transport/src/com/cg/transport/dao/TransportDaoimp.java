package com.cg.transport.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;



public class TransportDaoimp implements ITransportDao {
	Map<String, String> transportDetails=new HashMap<String,String>();
	
    }

