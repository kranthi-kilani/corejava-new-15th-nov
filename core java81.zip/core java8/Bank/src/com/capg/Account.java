package com.capg;


import java.util.Scanner;

 class Account {
	 private String createAccount;
	 private String name;
	 private Long showBalance;
	 private long amount;
	 private int pin;
	 Scanner sc=new Scanner(System.in);
	 void createAccount()
	 {
		 System.out.println("Create account no:\n");
		 createAccount=sc.next();
		 System.out.println("name of the accntholder:\n");
		 name=sc.next();
		 System.out.println("show balance:");
		 showBalance=sc.nextLong();
	 }
		 //account details
	 public void showAccount()
		 {
			 System.out.println(createAccount+" "+name+" "+showBalance);
			 
		 }
	
	 public void deposit()
		 {
			 long amount;
			 System.out.println("enter the amount to deposit:");
			 amount=sc.nextLong();
			 showBalance=showBalance+amount;
		 }
			 
	 public void withdraw()
			 {
				 long amount;
				 int pin1 = sc.nextInt();
				 if(pin==pin1){
					 
					 System.out.println("valid");
				 }else{
					 System.out.println("invalid");
					 
					 
				 }
				 System.out.println("enter the amount to withdraw:");
				 amount=sc.nextLong();
				 if(showBalance>=amount)
			     {
					 showBalance=showBalance-amount;
				 }
				 else
				 {
					 System.out.println("insufficient balance");
				 }
				 
		 }
	 public void printTranscations()
	 {
		
		 
		// System.out.println(createAccount+" "+name+" " +showBalance+" ");		 
		
		 
		 
	 }
			 //search for an account number
			 boolean search(String accnt)
			 {
				 if(createAccount.equals(accnt))
				 {
					 showAccount();
				     return (true);
			     }	 
			 
			 return (false);
             }
			
	 }
 
	 


