package com.capg;

import java.util.Scanner;

public class ShowAccount {
private static boolean found;
//Account a[]=new Account[n];
public static void main(String arg[])
	{
		Scanner sc=new Scanner(System.in);
		//create account
//		System.out.println("No.of accounts to be created:\n");
//		int n=sc.nextInt();
	Account a[]=new Account[n];
		for(int i=0;i<a.length;i++)
		{
			a[i]=new Account();
			a[i].createAccount();
						
		}
	
		int ch;
		do{
			System.out.println("Main Menu\n"
					+ "1.show account details\n "
					+ "2.Show bal\n "
					+ "3.Deposit\n  "
					+ "4.withdrawl\n "
					+ "5.printTranscation\n"
					+ "5.Exit");
					
				System.out.println("ur choice:");
					ch=sc.nextInt();
					switch(ch)
					{
//					case 1:
//						for(int i=0; i<a.length;i++)
//						{
//							a[i].showAccount();
//							
//						}
//						break;
//						
					case 1:
						    System.out.println("enter the account no:\n");
						    String accnt=sc.next();
						    boolean found=false;
						for(int i=0;i<a.length;i++)
							{
								found=a[i].search(accnt);
								if(found)
								{
								break;
								}
							
						}
						if(!found)
						{
							System.out.println("doesnt exit");
							
						}
					
					break;
		
					case 2:
						System.out.println("enter the account no:\n");
						 accnt = sc.next();
						found=false;
						for(int i=0;i<a.length;i++)
						{
													
							found=a[i].search(accnt);
							if(found)
							{
							a[i].deposit();
							break;
							}
							
							}
						if(!found)
						{
							System.out.println("search for the acnt no:");
						}
						break;
					case 4:
						System.out.println("enter the acnt number:");
						accnt =sc.next();
						found=false;
						for(int i=0;i<a.length;i++)
						{
							found=a[i].search(accnt);
							if(found)
							{
							a[i].withdraw();
							break;
							}
							
						}
						if(!found)
						{
							System.out.println("search for the acnt no:");
						}
						break;
					case 5:
						System.out.println("print the transcation\n");
						accnt=sc.next();
						found=false;
						for(int i=0;i<a.length;i++)
						{
							found=a[i].search(accnt);
							if(found)
							{
								a[i].printTranscations();
								break;
							}
						}
						if(!found)
						{
							System.out.println("no transcation valid\n");
						}
						break;
					case 6:
						System.out.println("exit");
						break;
		}
	}while(ch!=5);
						
						
									
							 
		}

	
	}


