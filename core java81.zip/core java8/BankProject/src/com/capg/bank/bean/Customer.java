package com.capg.bank.bean;

public class Customer {
	
	private int accNumber;
	private String name;
	private long mobile;
	private String email;
	private double balance;
	private int pin;
	private String transaction;
	
	
	public Customer(int accNumber, String name, int mobile, String email, double balance,int pin, String transaction) {
		super();
		this.accNumber = accNumber;
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.balance = balance;
		this.pin=pin;
		this.transaction=transaction;
	}


	public Customer() {
		// TODO Auto-generated constructor stub
	}


	public int getAccNumber() {
		return accNumber;
	}


	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}


	public String getName() {
		return name;
	}


	public void setName(String i) {
		this.name =name ;
	}


	public long getMobile() {
		return mobile;
	}


	public void setMobile(long l) {
		this.mobile = mobile;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String string) {
		this.email = email;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	public int getPin() {
		return pin;
	}


	public void setPin(int pin) {
		this.pin = pin;
	}


	public String getTransaction() {
		return transaction;
	}


	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}


	@Override
	public String toString() {
		return "Customer [accNumber=" + accNumber + ", name=" + name
				+ ", mobile=" + mobile + ", email=" + email + ", balance="
				+ balance + ", pin=" + pin + ", transaction=" + transaction
				+ "]";
	}


	

	

}
