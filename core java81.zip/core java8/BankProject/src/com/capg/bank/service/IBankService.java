package com.capg.bank.service;

import com.capg.bank.bean.Customer;

public interface IBankService {
	
	
   public int createAccount(Customer cus) ;
	public Customer showBalance(int accNumber) ;
	public boolean deposit(int num,double amount) ;
	 public boolean validateCustomer(Customer cus); 
	public boolean withdraw(int num,double amount); 
	public boolean fundTransfer(int num,int num1,double amount)  ;
	 public String printTransaction(int num) ;
  
}
