package com.capg.bank.exception;

public class AccountNotFound extends Exception {

}
