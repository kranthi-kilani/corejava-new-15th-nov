package com.capg.bank.ui;
import java.util.Scanner;




import com.capg.bank.bean.Customer;
//import com.capg.bank.service.BankServiceImp;
public class Client {
	Scanner sc= new Scanner(System.in);
	Customer cus=new Customer();
	
	public static void main(String[] args){
		
		
		
		
		int choice;
		
		
		
		Client c = new Client();

		while(true){
		System.out.println("---------Bank Application---------");
		System.out.println("1.create Account");
		System.out.println("2.Show Balance.");
		System.out.println("3.Deposit");
		System.out.println("4.Withdraw");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Print Transcations");
		System.out.println("7.exit");
		
		choice=c.sc.nextInt();
		switch (choice) {
		
		case 1:
			
			c.createAccount();
			break;
			
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
			
					
						
		}
		}
	
		
		 public void createAccount(){
			
			
			System.out.println("Enter customer name: ");
			cus.setName(sc.next());
			  
			System.out.println("Enter customer mobile number: ");
			cus.setMobile(sc.nextLong());
			System.out.println("Enter customer email: ");
			cus.setEmail(sc.next());
		    System.out.println("Enter  balance: ");
		    cus.setBalance(sc.nextDouble());
		    System.out.println("Enter pin");
			int pin = (sc.nextInt());
			System.out.println("renter the pin");
			int pin1=(sc.nextInt());
			
		    try {
				//boolean result = BankServiceImp.validateCustomer(cus);
				//if (result) {
					//int ret = BankServiceImp.createAccount(cus);
					//System.out.println( + ret + " created successfully");
					System.out.println("Set your pin: ");
					cus.setPin((sc.nextInt()));
					if(pin==pin1)
					{
						System.out.println("Your pin is set successfully!! ");
					}
					else
					{
						System.out.println("Invalid pin");
					}
					
				
		 }finally{}
}
//		    
//			} catch (Exception e) {
//				System.out.println();
//				System.err.println("error" + e.getMessage());
//				System.out.println();
			//}
	//	}	
//		 void showBalance() {
//				System.out.println("Enter customer Id whose balance you need to view: ");
//				int num = (sc.nextInt());
//				
//				try {
//					int pin;
//					if (pin == ) {
//
//						Customer cus = BankServiceImp.showBalance(num);
//						System.out.println(cus);
//					} else
//						System.out.println("Invalid pin");
//				} catch (Exception e) {
//					System.err.println("An error occured" + e.getMessage());
//				}
//
//			}
//			
		
		
		
		
		
		
		
	
	
	
	
	
	
	
		
	
	
 
