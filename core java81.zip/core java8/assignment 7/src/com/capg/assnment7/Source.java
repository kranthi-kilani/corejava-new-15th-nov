package com.capg.assnment7;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;



public class Source {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("enter the array elements");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("enter the elements");
		Source s=new Source();
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
			
		}
		HashMap<Integer,Integer> h=new HashMap<Integer,Integer>();
		System.out.println("the squares of the numbers:");
		h=s.getSquares(a);
		
		Set<Integer> set=h.keySet();
		Iterator<Integer> it= set.iterator();
		while(it.hasNext()){
			System.out.println(h.get(it.next()));
						
		}
		
		sc.close();
		
		
		
	}

	public  HashMap<Integer, Integer> getSquares(int numbers[] ) {
		// TODO Auto-generated method stub
		HashMap<Integer,Integer> h=new HashMap<Integer,Integer>();
		for(int i=0;i<numbers.length;i++)
		{
			int power=(int) Math.pow(numbers[i],2);
			h.put(numbers[i], power);
			
		}
		return h;
	}


}
