package com.capg.assnment9;

public class extra {

}


employee bean



//emplooyee service interface


//public EmployeeBean displayEmployee(int eid);

//====================================================================
//emp imp
//--------------------------------------------------

//@Override
//public EmployeeBean displayEmployee(int eid) {
//	// TODO Auto-generated method stub
//	return dao.displayEmployee(eid);
//}

//@Override
//public EmployeeBean displayEmployee(int eid) {
//	// TODO Auto-generated method stub
//	return null;
//}



//emp dao interface

//public EmployeeBean displayEmployee(int eid);

//emp dao imp



//@Override
//public EmployeeBean displayEmployee(int eid) {
//	// TODO Auto-generated method stub
//	
//	EmployeeBean emp= null;
//	for (EmployeeBean e: empList) {
//		if(eid==e.getEid()){
//	
//			emp=e;
//			
//}
//		
//	}
//	return emp;
//	
//}

//@Override
//public EmployeeBean displayEmployee(int eid) {
//	// TODO Auto-generated method stub
//	return null;
//}



//----------------------------------------------
//client


//case 2:
//	System.out.println("enter the eid to search");
//	int id=sc.nextInt();
//	
//	EmployeeBean emp =service.displayEmployee(id);
//	if(emp !=null){
//		
//	
//	System.out.println(emp);
////	}
//	else{
//		try{
//		throw new EmployeeNotFound();}
//		catch(EmployeeNotFound e1){
//			
//		
//		System.err.println("employee does not exit");
//		}
//	}
//	break;





