
package com.capg.assnment10;

import java.io.*;
import java.util.*;
 class Source {
    
    public static void main(String[] args) throws Exception {
        
File file =  new File("numbers.txt"); 

        FileOutputStream fos=new FileOutputStream("result.txt");

                Scanner sc = new Scanner(file); 
                String s=sc.nextLine();
                char[] c=s.toCharArray();
                
                
                //int l=c.length;
                for(char a:c){
                if(a !=','){
                    int k=(int)a;
                    if(k%2==0){
                        fos.write(k);
                        fos.write(13);
                    }
                    
                }
                
                }
                fos.close();

    }
    }
 
 
 
 
 
 
 
 
 
 
 
 
 //////////////////////////////////////////////////////////
 
 
 
 package com.cg.transportservice.ui;

 import java.time.LocalDateTime;
 import java.time.format.DateTimeFormatter;
 import java.util.Map;
 import java.util.Scanner;

 import com.cg.transportservice.bean.TicketBean;
 import com.cg.transportservice.exception.TicketException;
 import com.cg.transportservice.service.ITicketService;
 import com.cg.transportservice.service.TicketServiceImpl;

 public class Client {
 	public static void main(String[] args) {
 		try{
 		Scanner scanner = new Scanner(System.in);
 		TicketBean bean = new TicketBean();
 		ITicketService ticketService = new TicketServiceImpl();
 		Map<String, String> transportDetails = ticketService
 				.getTransportDetails();
 		System.out.println(" mode of transport :");
 		// set id
 		int id = (int) ((Math.random()) * 10000);
 		bean.setId(id);
 		// set TransportCategoryId
 		int count = 1;
 		for (Map.Entry<String, String> entrySet : transportDetails.entrySet()) {
 			System.out.println(count + ". " + entrySet.getValue());
 			count++;
 		}
 		System.out.println();
 		System.out.println(" enter transport option :");
 		int option = scanner.nextInt();
 		int count1 = 1;
 		for (Map.Entry<String, String> entrySet : transportDetails.entrySet()) {
 			if (count1 == option) {
 				bean.setTransportCategoryId(entrySet.getKey());
 				break;
 			}
 			count1++;
 		}
 		// set reason
 		System.out.println(" enter reason");
 		scanner.nextLine();
 		String reason = scanner.nextLine();
 		// or String reason = scanner.next();
 		
 		bean.setReason(reason);
 		// set when
 		System.out.println(" enter when");
 		System.out.println(" 1. this week \n 2. nect week \n 3. next month");
 		int whenChoice = scanner.nextInt();
 		if (whenChoice == 1) {
 			bean.setWhen("this week");
 		}else if (whenChoice == 2) {
 			bean.setWhen("next week");
 		}else if (whenChoice == 3) {
 			bean.setWhen("next month");
 		}
 		ticketService.addTransportTicket(bean);
 		LocalDateTime dateTime=LocalDateTime.now();
 		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd MMMM yyyy hh:mm a");
 		System.out.println(" bopoked with id "+bean.getId()+" on "+dateTime.format(format));
 		}catch(TicketException ticketException){
 			System.out.println("Error in fetching details and adding data");
 		}catch (Exception e) {
 			System.out.println(" internal error. try later.");
 		}
 	}
 }
 
 
 
 
 
 
 
 ////////////////////////////////////////////////////////////////////////////////
 package com.cg.transportservice.exception;

 public class TicketException extends Exception {

 	public TicketException() {
 		// TODO Auto-generated constructor stub
 	}

 	public TicketException(String message) {
 		super(message);
 		// TODO Auto-generated constructor stub
 	}

 	public TicketException(Throwable cause) {
 		super(cause);
 		// TODO Auto-generated constructor stub
 	}

 	public TicketException(String message, Throwable cause) {
 		super(message, cause);
 		// TODO Auto-generated constructor stub
 	}

 	public TicketException(String message, Throwable cause,
 			boolean enableSuppression, boolean writableStackTrace) {
 		super(message, cause, enableSuppression, writableStackTrace);
 		// TODO Auto-generated constructor stub
 	}

 }
 ---------------------------
 package com.cg.transportservice.service;

 import java.util.Map;

 import com.cg.transportservice.bean.TicketBean;
 import com.cg.transportservice.dao.ITicketDao;
 import com.cg.transportservice.dao.TicketDaoImpl;
 import com.cg.transportservice.exception.TicketException;

 public class TicketServiceImpl implements ITicketService {

 	private ITicketDao dao=new TicketDaoImpl();
 	
 	@Override
 	public Map<String, String> getTransportDetails() throws TicketException {
 		return dao.getTransportDetails();
 	}


 	@Override
 	public void addTransportTicket(TicketBean bean) throws TicketException {
 		dao.addTransportTicket(bean);
 	}

 	
 }
//////////////////////////////////////////////////////
 package com.cg.transportservice.dao;

 import java.util.Map;

 import com.cg.transportservice.bean.TicketBean;
 import com.cg.transportservice.exception.TicketException;

 public interface ITicketDao {

 	Map<String, String> getTransportDetails() throws TicketException;

 	void addTransportTicket(TicketBean bean) throws TicketException;

 }
 -----------------------------------
 package com.cg.transportservice.dao;

 import java.util.Map;

 import com.cg.transportservice.bean.TicketBean;
 import com.cg.transportservice.exception.TicketException;
 import com.cg.transportservice.util.DataBase;

 public class TicketDaoImpl implements ITicketDao {

 	@Override
 	public Map<String, String> getTransportDetails() throws TicketException {
 		return DataBase.getTransportDetails();
 	}

 	@Override
 	public void addTransportTicket(TicketBean bean)  throws TicketException {
 		DataBase.addTransportTicket(bean);
 	}

 }////////////////////////////////////////
 package com.cg.transportservice.bean;

 public class TicketBean {
 	private int id;
 	private String transportCategoryId;
 	private String reason;
 	private String when;
 	private String status = "new";

 	public int getId() {
 		return id;
 	}

 	public void setId(int id) {
 		this.id = id;
 	}

 	public String getTransportCategoryId() {
 		return transportCategoryId;
 	}

 	public void setTransportCategoryId(String transportCategoryId) {
 		this.transportCategoryId = transportCategoryId;
 	}

 	public String getReason() {
 		return reason;
 	}

 	public void setReason(String reason) {
 		this.reason = reason;
 	}

 	public String getWhen() {
 		return when;
 	}

 	public void setWhen(String when) {
 		this.when = when;
 	}

 	public String getStatus() {
 		return status;
 	}

 	public void setStatus(String status) {
 		this.status = status;
 	}

 }
       
