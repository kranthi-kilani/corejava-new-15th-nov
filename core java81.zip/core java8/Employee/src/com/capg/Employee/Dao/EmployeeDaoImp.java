package com.capg.Employee.Dao;

import java.util.ArrayList;

import com.capg.Employee.Bean.Employee;


public interface EmployeeDaoImp extends IEmployeeDao {
	
	
	
	ArrayList<Employee> empList=new ArrayList<Employee>();
	
	//public boolean addEmployee(Employee e);



}
