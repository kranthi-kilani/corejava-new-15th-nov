package com.capg.Employee.Dao;

import java.util.ArrayList;

import com.capg.Employee.Bean.Employee;


public interface IEmployeeDao {
	ArrayList<EmployeeDaoImp> empList=new ArrayList<EmployeeDaoImp>();
	
	public boolean addEmployee(EmployeeDaoImp e);


}
