package com.capg.Employee.Ui;
import java.util.ArrayList;
import java.util.Iterator;
import java.security.Provider.Service;
import java.util.Scanner;
import com.capg.Employee.Bean.Employee;
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		while(true){
		System.out.println("Insert Employee Details");
		
		Scanner sc = new Scanner(System.in);
		int ch = sc.nextInt();
		switch (ch) {

		case 1:
			System.out.println("enter eid");
			int eid=sc.nextInt();
			System.out.println("enter the enmae");
			String ename=sc.next();
			System.out.println("enter the salary");
			double sal=sc.nextDouble();
			Employee e=new Employee();
			e.setEid(eid);
			e.setEname(ename);
			e.setSal(sal);
			
			
			
		boolean isValid	=Service.validateData(e);
		if(isValid){
		boolean isAdded=Service.addEmployee(e);
		
		if(isAdded){
			
			
			System.out.println("thank u");
			System.out.println(e);
		}else
		{
			System.out.println("not added");
		}
		
		}
		else{
			System.err.println("invalid");
		}
			
			break;
		
		case 2:
			System.exit(0);
			
			break;
			default:
				
				
				break;

		}

	}

}
}
