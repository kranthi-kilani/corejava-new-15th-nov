package com.capg.Employee.Service;

import com.capg.Employee.Dao.EmployeeDaoImp;

import com.capg.Employee.Dao.IEmployeeDao;




public interface EmployeeServiceImp extends IEmployeeService {
	
	IEmployeeDao dao=new IEmployeeDao() {
		
		@Override
		public boolean addEmployee(EmployeeDaoImp e) {
			// TODO Auto-generated method stub
			return false;
		}
	}


	@Override
	public default boolean addEmployee(EmployeeDaoImp e) {
		// TODO Auto-generated method stub
		return dao.addEmployee(e);
	}
	public default boolean validateData(EmployeeDaoImp e){
		boolean isValid=false;
		if(e.getEname().length()>4 && e.getSal()>0){
			
			
			isValid=true;
			
		}
		return isValid;


	}
}
