package com.capg.Employee.Service;

import com.capg.Employee.Dao.EmployeeDaoImp;



public interface IEmployeeService {
	public boolean addEmployee(EmployeeDaoImp e);
	public boolean validateData(EmployeeDaoImp e);
	
	

}
