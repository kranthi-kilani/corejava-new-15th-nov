package com.cg.tms.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Scanner;

import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;
import com.cg.tms.util.Util;

public class MainUI {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		TicketService service = new TicketServiceImpl();
		System.out.println("********Menu**********");
		System.out.println("1.Raise A ticket");
		System.out.println("2.Exit from the system");
		int ch = sc.nextInt();
		// using switch case
		switch (ch) {
		case 1:
			TicketCategory bean = new TicketCategory();
			Map<String, String> ticket = service.getTicketCategoryEntries();
			System.out.println("Select Ticket Category from below List");
			int count = 1;
			for (Map.Entry<String, String> entrySet : ticket.entrySet()) {
				System.out.println(count + ". " + entrySet.getValue());
				count++;
			}
			//Entering the option
			System.out.println("Enter Option:");
			int choice = sc.nextInt();
			int count1 = 1;
			for (Map.Entry<String, String> entrySet : ticket.entrySet()) {
				if (choice == count1) {

					bean.setTicketCategoryId(entrySet.getKey());
				}
				count1++;
			}
			// setting the TicketNo using Random number
			int ticketNo = (int) (Math.random() * 10000);
			bean.setTicketNo(ticketNo);
			// describing the issue
			System.out.println("Enter Description related to issue");
			sc.nextLine();
			String ticketDescription = sc.nextLine();
			bean.setTicketDescription(ticketDescription);
			// setting the priority
			System.out.println("Enter Priority");
			System.out.println("1.low 2.medium 3.high");
			int ticketPriority = sc.nextInt();
			if (ticketPriority == 1) {
				bean.setTicketPriority("1.low");
			}
			if (ticketPriority == 2) {
				bean.setTicketPriority("2.medium");
			}
			if (ticketPriority == 3) {
				bean.setTicketPriority("3.high");
			}
			// raising new ticket
			service.raiseNewTicket(bean);
			// Local date time
			LocalDateTime ldt = LocalDateTime.now();
			DateTimeFormatter f = DateTimeFormatter
					.ofPattern("dd MMMM yyyy hh : mm a");
			System.out.println("TicketNUmber " + ticketNo
					+ " logged successfully at " + ldt.format(f));

			break;
		case 2:
			System.exit(0);
			break;

		}
	}
}
