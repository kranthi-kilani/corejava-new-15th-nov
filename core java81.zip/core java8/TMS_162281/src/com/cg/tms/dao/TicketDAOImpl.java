package com.cg.tms.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.Util;

public class TicketDAOImpl implements TicketDAO {
	Map<String, String> ticketCategory = new HashMap<String, String>();

	@Override
	public Map<String, String> getTicketCategoryEntries() {
		// TODO Auto-generated method stub
		return Util.getTicketCategoryEntries();
	}

	@Override
	public boolean raiseNewTicket(TicketCategory bean) {
		// TODO Auto-generated method stub
		Util.raiseNewRequest(bean);
		return true;
	}

}
