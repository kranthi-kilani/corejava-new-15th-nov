package com.cg.tms.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketCategory;

public class TestDAOImplTest {
	TicketCategory bean = new TicketCategory();
	static TicketDAO service = null;

	@BeforeClass
	public static void createInstance() {
		service = new TicketDAOImpl();
	}

	@Test
	public void testRaiseNewRequest() {
		TicketCategory tc = new TicketCategory();
		tc.setTicketCategoryId("tc001");
		tc.setTicketDescription("journey");
		tc.setTicketNo(122);
		tc.setItimdComments("gedfj");
		tc.setTicketStatus("new");
		tc.setTicketPriority("low");
		boolean result = service.raiseNewTicket(tc);
		assertTrue(result);

	}

}
