package com.cg.tms.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.tms.dto.TicketCategory;

public class Util {
	private static Map<String, String> ticketCategory = new HashMap<String, String>();
	private static Map<Integer, TicketCategory> ticketDetails = new HashMap<>();

	public static Map<String, String> getTicketCategoryEntries() {
		ticketCategory.put("tc001", "software insatallation");
		ticketCategory.put("tc002", "mailbox creation");
		ticketCategory.put("tc003", "mailbox issues");
		return ticketCategory;
	}

	public static void raiseNewRequest(TicketCategory bean) {
		// TODO Auto-generated method stub
		ticketDetails.put(bean.getTicketNo(), bean);
	}

}
