package com.cg.tms.service;

import java.util.Map;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketCategory;

public class TicketServiceImpl implements TicketService {
	TicketDAO dao = new TicketDAOImpl();

	@Override
	public Map<String, String> getTicketCategoryEntries() {
		// TODO Auto-generated method stub
		return dao.getTicketCategoryEntries();
	}

	@Override
	public void raiseNewTicket(TicketCategory bean) {
		// TODO Auto-generated method stub
		dao.raiseNewTicket(bean);
	}

}
