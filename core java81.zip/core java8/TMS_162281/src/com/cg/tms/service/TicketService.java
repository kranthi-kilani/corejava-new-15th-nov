package com.cg.tms.service;

import java.util.Map;

import com.cg.tms.dto.TicketCategory;

public interface TicketService {

	Map<String, String> getTicketCategoryEntries();

	void raiseNewTicket(TicketCategory bean);

}
