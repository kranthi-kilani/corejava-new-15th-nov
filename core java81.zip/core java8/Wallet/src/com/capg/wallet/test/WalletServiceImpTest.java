package com.capg.wallet.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.wallet.bean.CustomerBean;
import com.capg.wallet.service.IWalletService;
import com.capg.wallet.service.WalletServiceImp;

public class WalletServiceImpTest {

	
	private static IWalletService walletService=null;
	
	@BeforeClass
	public static void testDetails() {
		
		walletService =new WalletServiceImp();
		
		}
	@Test(expected=WalletException.class)
	public  void testPhoneNumForLength() throws WalletException{
		    CustomerBean cb=new CustomerBean();
		    cb.setFirstName("kranthi");
		    cb.setLastName("kilani");
		    cb.setBalance(700);
		    cb.setEmailId("kranthi@gmail.com");
		    cb.setPhoneNum("658860");
		        boolean result= walletService.validateData(cb);
      assertFalse(result);
      
		
	}
	@Test
	public  void testPhoneNum() throws WalletException{
		    CustomerBean cb=new CustomerBean();
		    cb.setFirstName("kranthi");
		    cb.setLastName("kilani");
		    cb.setBalance(7000);
		    cb.setEmailId("kranthi@gmail.com");
		    cb.setPhoneNum("9845876860");
		        boolean result= walletService.validateData(cb);
      assertTrue(result);
   	}
	@Test(expected=WalletException.class)
	public  void testBalanceGreaterThanZero() throws WalletException{
		    CustomerBean cb=new CustomerBean();
		    cb.setFirstName("kranthi");
		    cb.setLastName("kilani");
		    cb.setBalance(30);
		    cb.setEmailId("kranthi@gmail.com");
		    cb.setPhoneNum("07458860");
		        boolean result= walletService.validateData(cb);
      assertFalse(result);
      
		
	}

@Test(expected=WalletException.class)
public  void testBalanceNotNull() throws WalletException{
	    CustomerBean cb=new CustomerBean();
	    cb.setFirstName("kranthi");
	    cb.setLastName("kilani");
	    cb.setBalance(-1);
	    cb.setEmailId("kranthi@gmail.com");
	    cb.setPhoneNum("07458860");
	        boolean result= walletService.validateData(cb);
  assertFalse(result);
  
	
}

@Test(expected=WalletException.class)
public  void testBalanceNotEqualtoZero() throws WalletException{
	    CustomerBean cb=new CustomerBean();
	    cb.setFirstName("kranthi");
	    cb.setLastName("kilani");
	    cb.setBalance(10);
	    cb.setEmailId("kranthi@gmail.com");
	    cb.setPhoneNum("07458860");
	        boolean result= walletService.validateData(cb);
  assertFalse(result);
  
	
}
	
@Test
public  void testBalance() throws WalletException{
	    CustomerBean cb=new CustomerBean();
	    cb.setFirstName("kranthi");
	    cb.setLastName("kilani");
	    cb.setBalance(1000);
	    cb.setEmailId("kranthi@gmail.com");
	    cb.setPhoneNum("9074588603");
		 boolean result= walletService.validateData(cb);
  assertTrue(result);
  
}
	
	
}	
	
	
	
	
	
	
	

