package com.capg.wallet.test;

public class WalletException extends Exception {
	

	public  WalletException(){
		
	}
	public  WalletException(String args){
		super();
	}

}
