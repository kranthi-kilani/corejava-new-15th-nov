package com.capg.wallet.dao;

import java.util.Scanner;

import com.capg.wallet.bean.CustomerBean;
import com.capg.wallet.test.WalletException;

public class WalletDaoImp implements IWalletDao {
	CustomerBean cb=new CustomerBean();
	Scanner sc=new Scanner(System.in);

	@Override
	public boolean createAccount(CustomerBean customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double ShowBalance( CustomerBean bean1) {
		// TODO Auto-generated method stub
		
		
		System.out.println(cb.getFirstName()+","+cb.getBalance());
		return bean1;
	
	
	}
	public boolean withdraw(CustomerBean bean1){
		for(CustomerBean bean:list){
			
			
		}
		
		return false;
		
	}
	
	
	
	

//	@Override
//	public boolean withdraw(double amount) {
//		boolean isValid=false;
//		System.out.println("enter the mobile num");
//		//String phoneNum1=sc.next();
//		String phoneNum1=cb.getPhoneNum();
//		if(cb.getPhoneNum()==phoneNum1){
//			if(cb.getBalance() > amount &&  amount!=0){
//			cb.setBalance(cb.getBalance()-amount);
//			System.out.println("Balance amount: "+cb.getBalance());	
//			isValid=true;
//		}else{
//			System.err.println("Inavlid mobile number");
//		}
//			ShowBalance(amount);
//		}
//				return isValid;
//		
//	}
				
	@Override
	public boolean deposit(CustomerBean bean1) {
		// TODO Auto-generated method stub
		boolean isValid=true;
		System.out.println("enter the mobile num");
		String phoneNum1=cb.getPhoneNum();
		//String phoneNum1=sc.next();
		if(cb.getPhoneNum()==phoneNum1){
			if(cb.getBalance() > amount &&  amount!=0){
			cb.setBalance(cb.getBalance()+amount);
			System.out.println("Balance amount: "+cb.getBalance());
			isValid=true;
		}else{
			System.err.println("Inavlid mobile number");
		}
		ShowBalance(bean1);
		}
		return isValid;
	}
	

	@Override
	public boolean fundTransfer() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean printTranscation() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateData(CustomerBean cb)throws WalletException {
		// TODO Auto-generated method stub
		

		
		
		
		
		return false;
	}

}
