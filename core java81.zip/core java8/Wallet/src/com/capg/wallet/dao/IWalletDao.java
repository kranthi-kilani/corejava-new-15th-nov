package com.capg.wallet.dao;

import com.capg.wallet.bean.CustomerBean;
import com.capg.wallet.test.WalletException;

public interface IWalletDao {

	
	public boolean createAccount(CustomerBean customer);
	public double ShowBalance(double amount);
	public boolean withdraw(CustomerBean bean1);
	public boolean deposit(CustomerBean bean1);
	public boolean fundTransfer();
	public boolean printTranscation();
	
	public boolean validateData(CustomerBean cb) throws WalletException;
	
}
