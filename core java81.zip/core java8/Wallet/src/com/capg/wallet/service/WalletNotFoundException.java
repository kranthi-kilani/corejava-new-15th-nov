package com.capg.wallet.service;

public class WalletNotFoundException extends Exception{

	public static final String ERROR1 = "firstname should not be empty and contains characters";
	public static final String ERROR2 = "last name should contain characters";
	public static final String ERROR3 = "Balance should be greater than zero";
	public static final String ERROR4 = "phone number should contain 10 digits";
	public static final String ERROR5 = "email id should contain @ symbol";
	
	

}
