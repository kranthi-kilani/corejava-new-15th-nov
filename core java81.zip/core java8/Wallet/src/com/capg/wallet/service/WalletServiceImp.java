package com.capg.wallet.service;

import com.capg.wallet.bean.CustomerBean;
import com.capg.wallet.dao.IWalletDao;
import com.capg.wallet.dao.WalletDaoImp;
import com.capg.wallet.test.WalletException;

public class WalletServiceImp implements IWalletService {
	IWalletDao dao=new WalletDaoImp();

	@Override
	public boolean createAccount(CustomerBean customer) {
		// TODO Auto-generated method stub
		return false;
	}

	public double ShowBalance(double amount) {
		// TODO Auto-generated method stub
		return dao.ShowBalance(amount);
	}

	@Override
	public boolean withdraw(CustomerBean bean1) {
		// TODO Auto-generated method stub
		return dao.withdraw(bean1);
	}

	@Override
	public boolean deposit(CustomerBean bean1) {
		// TODO Auto-generated method stub
		return dao.deposit(bean1);
	}

	@Override
	public boolean fundTransfer() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean printTranscation() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateData(CustomerBean cb)throws WalletException {
		// TODO Auto-generated method stub
		 boolean isValid=false;
		if(!(cb.getPhoneNum().matches("[7-9][0-9]{9}"))){
            throw new WalletException(WalletNotFoundException.ERROR4);
          
        }
	
        if(!(cb.getFirstName().matches("[A-Z][A-Za-z]*")&&cb.getFirstName()!=null)){
              throw new WalletException(WalletNotFoundException.ERROR1);
             
        }
        if(!(cb.getLastName().matches("[A-Z][A-Za-z]*"))){
              throw new WalletException(WalletNotFoundException.ERROR2);
              
        }
        if(!(cb.getBalance()>500) && cb.getBalance()!=0){
      	  
              throw new WalletException(WalletNotFoundException.ERROR3);
            
        }
        
        
        if(!(cb.getEmailId().matches("[A-ZA-Za-z0-9]+@+[a-z]+\\.com"))){
        	throw new WalletException(WalletNotFoundException.ERROR5);
        }
        	
isValid=true;


return isValid;
		
		
		
		
		
		
		
		
		
	}

}
