package com.capg.wallet.service;

import com.capg.wallet.bean.CustomerBean;
import com.capg.wallet.test.WalletException;

public interface IWalletService {

	public boolean createAccount(CustomerBean customer);
	public double ShowBalance(double amount);
	public boolean withdraw(CustomerBean bean1);
	public boolean deposit(double amount);
	public boolean fundTransfer();
	public boolean printTranscation();
	public boolean validateData(CustomerBean cb) throws WalletException;
	
	
	
	
}
