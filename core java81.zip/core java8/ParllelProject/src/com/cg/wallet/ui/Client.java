package com.cg.wallet.ui;

import java.math.BigInteger;
import java.util.Scanner;

import com.cg.wallet.bean.CustomerBean;
import com.cg.wallet.service.IServiceWallet;
import com.cg.wallet.service.ServiceWalletImpl;

public class Client {

	static CustomerBean bean = new CustomerBean();
	static IServiceWallet service = new ServiceWalletImpl();

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
while(true){
		System.out.println("**********WELCOME TO WALLET PAYMENT**********");
		System.out.println("1.Create Account");
		System.out.println("2.Deposit");
		System.out.println("2.Withdraw");
		System.out.println("3.ShowBalance");
		System.out.println("5.FundTransfer");
		System.out.println("6.PrintTranscations");
		System.out.println("---------------------------");
		System.out.println("Enter Your Choice: ");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			createAccount();

			break;

		case 2:
			deposit();

			break;

		case 3:
			withdraw();
			break;

		case 4:
			showBalance();
			break;

		case 5:
			fundTransfer();
			break;

		case 6:

			printTranscation();

			break;

		}

	}
	}

	private static void printTranscation() {
		// TODO Auto-generated method stub

	}

	private static void fundTransfer() {
		// TODO Auto-generated method stub

	}

	private static void showBalance() {
		

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter pin number:");
		int pin1 = sc.nextInt();
		if (pin1 == bean.getPin()) {
			double amt = 0.0;
			service.showBalance(amt);
		} else {
			System.out.println("Invalid pin number");
		}
	}

	private static void withdraw() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter pin number:");
		int pin1 = sc.nextInt();
		if (pin1 == bean.getPin()) {
			/*
			 * System.out.println("enter amount to deposit"); Double amt =
			 * sc.nextDouble();
			 */
			double amount = 0.0;
			double balance = service.withdraw(amount);
			System.out.println("Amount is deposited to your account");
			/*
			 * System.out.println("the total balance in your account is "
			 * +balance);
			 */
		}

	}

	private static void deposit() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter pin number:");
		int pin1 = scanner.nextInt();
		if (pin1 == bean.getPin()) {
			/*
			 * System.out.println("enter amount to deposit"); Double amt =
			 * sc.nextDouble();
			 */
			//double amount1 = 0.0;
		    System.out.println("Enter the amount to be deposited: ");
		      double amount=scanner.nextDouble();
		 service.deposit(amount);
			System.out.println("Amount is deposited to your account");
			/*
			 * System.out.println("the total balance in your account is "
			 * +balance);
			 */

		}
	}

	private static void createAccount() {
		CustomerBean bean = new CustomerBean();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter name:");
		String name = scanner.next();
		bean.setName(name);
		System.out.println("Enter EmailId:");
		String emailId = scanner.next();
		bean.setEmailId(emailId);
		System.out.println("Enter phoneNumber:");
		BigInteger phno = scanner.nextBigInteger();
		bean.setPhno(phno);
		System.out.println("enter the balance");
		double balance = scanner.nextDouble();

		System.out.println("Account created successfully..");

	}

}
