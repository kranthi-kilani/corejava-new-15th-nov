package com.cg.wallet.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.wallet.bean.CustomerBean;
import com.cg.wallet.util.WalletDB;

public class WalletDAOImpl implements IWalletDAO {
	WalletDB db = new WalletDB();
	CustomerBean bean = new CustomerBean();
	static Scanner scanner=new Scanner(System.in);
	ArrayList<CustomerBean> cusList = new ArrayList<>();
	List<CustomerBean> customerList = WalletDB.getList();

	//List<WalletTransactions> transacList = new ArrayList<WalletTransactions>();

	@Override
	public boolean createCustomer(CustomerBean bean) {

		return cusList.add(bean);
	}

	@Override
	public double deposit(double amount) {

		double amt=bean.getBalance() + amount;
		bean.setBalance(amt);
		LocalDateTime ldt = LocalDateTime.now();
		bean.setLdt(ldt);
		System.out.println("ShowBal:" + bean.getBalance());
		cusList.add(bean);
		return amt;
	}

	@Override
	public double withdraw(double amount) {
		
  
		double amt=bean.getBalance() - amount;
		bean.setBalance(amt);
		LocalDateTime ldt = LocalDateTime.now();
		bean.setLdt(ldt);
		System.out.println("ShowBal:" + bean.getBalance());
		cusList.add(bean);
		return amt;
	}

	@Override
	public double showBalance(double amount) {

		System.out.println("the total balance in your account is " + bean.getBalance());

		return 0;
	}

	@Override
	public boolean fundTransfer() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean printTranscation() {
		// TODO Auto-generated method stub
		return false;
	}

}
