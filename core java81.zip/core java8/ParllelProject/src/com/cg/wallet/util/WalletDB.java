package com.cg.wallet.util;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.cg.wallet.bean.CustomerBean;

public class WalletDB {
private static List<CustomerBean> customerList = new ArrayList<CustomerBean>();
	
	
	static CustomerBean bean1 = new CustomerBean();
	static CustomerBean bean2 = new CustomerBean();
	static{
		
	bean1.setName("Priya");
	bean1.setEmailId("priyajoseph23@gmail.com");
	bean1.setPhno(new BigInteger("9979896543"));
	bean1.setBalance(2000);
	bean1.setLdt(LocalDateTime.now());
	customerList.add(bean1);
	
	bean2.setName("John");
	bean2.setEmailId("johnmicheal@gmail.com");
	bean2.setPhno(new BigInteger("9979896544"));
	bean2.setBalance(5000);
	bean2.setLdt(LocalDateTime.now());
	customerList.add(bean2);
	
	
}
	public static List<CustomerBean> getList(){
		return customerList;
	}
}
	
	


