package com.cg.wallet.bean;

public class Customer {
	
	

}
