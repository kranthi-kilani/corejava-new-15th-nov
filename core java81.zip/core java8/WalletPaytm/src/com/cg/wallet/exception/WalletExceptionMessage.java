package com.cg.wallet.exception;

public class WalletExceptionMessage {

}
