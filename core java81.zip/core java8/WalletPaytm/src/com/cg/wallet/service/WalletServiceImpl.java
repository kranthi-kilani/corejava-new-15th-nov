package com.cg.wallet.service;

public class WalletServiceImpl implements IWalletService {

}
