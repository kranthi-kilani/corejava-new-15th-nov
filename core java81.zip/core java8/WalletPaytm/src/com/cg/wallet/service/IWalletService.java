package com.cg.wallet.service;

public interface IWalletService {

}
