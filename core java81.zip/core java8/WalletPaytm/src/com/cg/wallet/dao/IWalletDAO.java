package com.cg.wallet.dao;

public interface IWalletDAO {

}
