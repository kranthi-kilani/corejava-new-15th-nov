package com.cg.wallet.dao;

public class WalletDAOImpl implements IWalletDAO {

}
