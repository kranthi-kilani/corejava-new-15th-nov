import java.math.BigInteger;
import java.util.Scanner;
public class Person{
    static String firstName;
    static String lastName;
    public enum Gender
    {
        F,M;
    }
static Gender gender;
public Gender gender()
{
    try{
        char gender1 =sc.next().charAt(0);
        String gender2=String.valueOf(gender1);
        gender=Gender.valueOf(gender2);
        
    }catch(Exception e)
    {
        e.printStackTrace();
    }
    
	return gender;
    }
Scanner sc=new Scanner(System.in);
public String firstName()
{
    firstName=sc.next();
    return firstName;
}
    public String lastName()
    {
        lastName=sc.next();
        return lastName;
    }
    static BigInteger number;
    public BigInteger acceptPhoneNumber()
    {
        try{
            number =sc.nextBigInteger();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return number;
    }
    Person(){}
    public Person(String firstName,String lastName,Gender gender,BigInteger number)
    {
        this.firstName=firstName;
        this.lastName=lastName;
        this.gender=gender;
        this.number=number;
        
    }
    public String getFirstName()
    {
        return firstName;
    }
    public void setFirstName(String firstName)
    {
        this.firstName=firstName;
    }
    public String getLastName()
    {
        return lastName;
    }
    public void setLastName(String lastName)
    {
        this.lastName=lastName;
    }
    public Gender getGender()
{
    return gender;
}
public void setGender(Gender gender)
{
    this.gender=gender;
}
public void displayDetail(Person p)
{
    firstName();
    lastName();
    gender();
    acceptPhoneNumber();
    System.out.println("Firstname:"+p.firstName);
    System.out.println("Lastname:"+p.lastName);
    System.out.println("Gender:"+p.gender);
    System.out.println("Phonenumber:"+p.number);
    
}
public static void main(String[] args)
{
	char g;
	Person p=new Person(firstName,lastName,gender,number);
	p.displayDetail(p);
	}
}
