import java.math.*;
 public class person
 {
   private String firstName,lastName;
    private Gender gender;
    private Integer number;
    Person()
    {
        System.out.println("Default constructor");
    }
    
    public  Person(String firstname,String lastname,char gender,Integer number)
    {
        this.firstName=firstname;
        this.lastName=lastname;
        this.gender=gender;
        
    }
    public Integer phonenumber(Integer number)
    {
        this.number=number;
        return number;
    }
    public String getFirstName()
    {
        return firstname;
    }
    public void setFirstName(String firstname)
    {
        return firstname;
    }
    public String getLastName(){
        return lastname;
    }
    public void setLastName(String lastname)
    {
        return lastname;
    } 
    public  char getGender()
    {
        return gender;
    }
    public void setGender(char gender)
    {
        if(gender=M)
        {
            System.out.println("male");
        }    
            else if(gender=F)
            {
                System.out.println("female");
                
            }
            
        }
        public Integer getNumber(){
            return getNumber;
        }
        }
       
    }    
}
/*public enum Gender{
    M,F
}*/
   public void displayDetails(){
            p.setFirstName("aaaa");
              String f=p.getFirstName();
              p.setLastName("hhhh");
              String l=p.getLastName();
               p.setGender(gender.M);
              p.getGender();
              p.acceptPhoneNumber(12344555);
              p.displayDetails(p);
       
      
   }
   
   
   
   
   
   
   
   
   
    
}