package cpm.capg;
import java.util.Scanner;
class Account extends Person {
    // complete the class
    static long accNum;
    static double balance;
    Person accHolder;
    static double rupees;
   Account() {
        name();
        age();
        balance();
    }
    static Scanner sc=new Scanner(System.in);
	private static double amount;
       private static String name() {
           System.out.println("enter the name");
           name = sc.nextLine();
           return name;
       }
       private static float age() {
                System.out.println("enter the age");
               age = sc.nextFloat();
               return age;
       }
       private  double balance() {
               System.out.println("enter the balance");
               balance = sc.nextDouble();
              Account.setAccountDetails(name,age,balance);
              return balance;
       }
           Account(String name, float age, double balance) {
              Person.name = name;
              Person.age = age;
              Account.balance = balance;
              generateAccnNumber();
           }
           
            public void deposit(double amount) {
          
               System.out.println("enter the amount to be deposited");
               amount = sc.nextDouble();
               balance = balance + amount;
               System.out.println("the total amount is "+balance);
            }
       
             public void withdraw(double amount) {
             
               System.out.println("enter the amount to be withdrawed");
               amount = sc.nextDouble();
               if(rupees < balance){ 
                   balance = balance - amount;
                   System.out.println("the total amount is "+balance);
               }
               else {
                   System.out.println("Insufficient balance");
               }
               
             }
            
             public String toString() {
             
               return("Name:"+Person.name+"\n"+"Age:"+Person.age+"\n"+"AccnNumber:"+accNum+"\n"+"Balance"+balance+"\n");
             }
           
            public static  double getBalance() {
              
               System.out.println("your balance:");
              return balance;
             }
             
             public static  void setBalance(double bal){
                            Account.balance = bal;
              generateAccnNumber();
            }  
           
             public static  void setAccountDetails(String name, float age, double balance) {
                              Person.name = name;
              Person.age = age;
                  Account.balance = balance;
                generateAccnNumber();
             }
           
             public Person getPerson(Person p){
              
                accHolder = p;
                   return accHolder;
             }
              public static  long generateAccnNumber(){
                    if(Account.balance <= 500){
                       System.out.println("balance should be greater than 500 ");
                        double b;
                        System.out.println("enter amount in to the account:");
                        b = sc.nextDouble();
                        setBalance(b);
                    }
                
                    else {

                        accNum = (long)(Math.random()*100000 + 3524400000L);
                    }
                    return accNum;

                }
             public static void main(String[] args) {
                     Account a = new Account();
              System.out.println(a.toString());
              
                     Account a1 = new Account(Person.name,Person.age,Person.balance);
                     System.out.println(a1.toString());
                     a1.deposit(amount);
                     a1.withdraw(amount);
                   
              } 
}



