package cpm.capg;

import java.util.Scanner;

public class Person {

    Scanner sc = new Scanner(System.in);
    public static String name;
    public static float age;
    public static double balance;
    

	
 public String getName() 
 {
        return name;
 }
 public void setName(String name)
 {
        Person.name = name;
 }
 public float getAge()
 {
        return age;
 }
 public void setAge(float age) 
 {
        Person.age = age;
 }

}

